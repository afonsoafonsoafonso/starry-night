Instruções de Utilização (já no Sicstus):
    - consult('starrynight.pl').
    - start.

Grupo Starry Night_2
Afonso Mendonça (201706708)
Filipe Nogueira (201604129)